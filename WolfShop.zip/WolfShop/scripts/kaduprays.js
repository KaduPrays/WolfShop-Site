if (console && console.log) {
    console.log("Site desenvolvido por KaduPrays em 2021 com todos os direitos reservados!");
}